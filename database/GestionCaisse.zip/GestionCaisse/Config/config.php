<?php

return [
    'name' => 'GestionCaisse'
];
