<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('ligne_factures', function (Blueprint $table) {
            $table->string('mode_paiement')->nullable()->after('total_ligne');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('ligne_factures', function (Blueprint $table) {
            $table->dropColumn('mode_paiement');
        });
    }
};
