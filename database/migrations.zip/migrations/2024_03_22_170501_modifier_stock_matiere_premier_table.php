<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('stock_matiere_premieres', function (Blueprint $table) {
            $table->datetime('date_entree')->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('stock_matiere_premieres', function (Blueprint $table) {
            $table->dropColumn('date_entree');
        });
    }
};
